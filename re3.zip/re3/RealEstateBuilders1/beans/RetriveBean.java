package com.RealEstateBuilders1.beans;

import java.io.Serializable;

public class RetriveBean implements Serializable
{
   private String customerName;
   private String buildingName;
   private String buildingPrice;
   private String customerType;
public RetriveBean() {
	super();
}
public RetriveBean(String customerName, String buildingName,
		String buildingPrice, String customerType) {
	super();
	this.customerName = customerName;
	this.buildingName = buildingName;
	this.buildingPrice = buildingPrice;
	this.customerType = customerType;
}
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public String getBuildingName() {
	return buildingName;
}
public void setBuildingName(String buildingName) {
	this.buildingName = buildingName;
}
public String getBuildingPrice() {
	return buildingPrice;
}
public void setBuildingPrice(String buildingPrice) {
	this.buildingPrice = buildingPrice;
}
public String getCustomerType() {
	return customerType;
}
public void setCustomerType(String customerType) {
	this.customerType = customerType;
}
   
   
}
