package com.RealEstateBuilders1.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.RealEstateBuilders1.beans.LoginBean;

public class LoginDao {
	private HibernateTemplate ht;

	public String validating(LoginBean lb)
	{
		String s;
		List l;
		l=ht.find("select role from LoginBean where userName='"+lb.getUserName()+"' and passWord='"+lb.getPassWord()+"'");
		System.out.println("Dao Validating method");
		if(l.size()!=0)
		{
		s=(String) l.get(0);
		return s;
		}
		else
		{
			return "invalid";
		}
		
	}
	public void setHt(HibernateTemplate ht)
	{
		System.out.println("Dao setht method");
		this.ht=ht;
	}
}
