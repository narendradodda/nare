package com.RealEstateBuilders1.dao;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.RealEstateBuilders1.beans.RegisterBean;

public class RegisterDAOImplementation implements RegisterDAO {

	private HibernateTemplate ht;
	
	@Override
	public void insertCustomer(RegisterBean rb) {
		
		System.out.println("RegisterDaoImp insertCustomer method");
		System.out.println("insertEmp of EmpDAOImpl class.....");
        ht.saveOrUpdate(rb);
	}
	
	public void setHt(HibernateTemplate ht) {
        this.ht = ht;
        System.out.println("RegisterDaoImp setHt method");
    }

}
