package com.RealEstateBuilders1.service;

import com.RealEstateBuilders1.beans.LoginBean;
import com.RealEstateBuilders1.dao.LoginDao;

public class LoginService {
      private LoginDao loginDao;

	public String validating(LoginBean lb)
	{
		System.out.println("Service Validating method");
		return loginDao.validating(lb);
	}
	
	public void setLoginDao(LoginDao loginDao)
	{
		System.out.println("Service setlogindao method");
		this.loginDao=loginDao;
	}
}
