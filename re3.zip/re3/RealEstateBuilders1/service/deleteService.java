package com.RealEstateBuilders1.service;

import com.RealEstateBuilders1.beans.RegisterBean;
import com.RealEstateBuilders1.dao.deleteDAO;





public class deleteService 
{

	private deleteDAO cusDAO;

	
	public void deleteDetails(RegisterBean rb) {
		
		System.out.println("insertEmp method of EmpServiceImpl method!!!");
		cusDAO.deleteDetails(rb);
	}
	
	public void setCusDAO(deleteDAO cusDAO) {
        this.cusDAO = cusDAO;
    }

}
