package com.RealEstateBuilders1.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.RealEstateBuilders1.beans.RetriveBean;
import com.RealEstateBuilders1.service.RetriveService;



@Controller
public class RetrieveController {
	
	@Autowired
	private RetriveService service;
	
	@RequestMapping(value="/retrieve.html",method=RequestMethod.POST)
	public ModelAndView validate(@ModelAttribute("cmdrtv")RetriveBean lb,HttpServletRequest request){
		List l=service.validate(lb);
		System.out.println(service.validate(lb));
		HttpSession session=request.getSession();
		session.setAttribute("details", l);
		return new ModelAndView("retrievingDetails","List",l);
	}
	
	
	public  void setService(RetriveService service){
		this.service=service;
	}
	public  RetriveService getService(){
		return service;
	}

}
