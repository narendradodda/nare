package com.RealEstateBuilders1.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.RealEstateBuilders1.beans.LoginBean;

import com.RealEstateBuilders1.service.LoginService;

@Controller
public class LoginController {
	@Autowired
	private LoginService loginService;
	@RequestMapping(value="/jk.html",method=RequestMethod.POST)
	public ModelAndView validating(@ModelAttribute("cmdlog")LoginBean lb)
	{ 
		
		System.out.println("Controller validating method");
		String s=loginService.validating(lb);
		if(s.equalsIgnoreCase("administrator"))
				{
	
		return new ModelAndView("Administrator");
				}
		else if(s.equalsIgnoreCase("customer"))
		{
			return new ModelAndView("customer");
		}
		else{
			return new ModelAndView("errorPage");
		}

		
	}
	public void setLoginService(LoginService loginService)
	{
		System.out.println("controller setloginservice  method");
		this.loginService=loginService;
	}
	
	
}
