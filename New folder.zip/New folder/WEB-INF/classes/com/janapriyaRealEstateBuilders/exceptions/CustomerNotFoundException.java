package com.janapriyaRealEstateBuilders.exceptions;

public class CustomerNotFoundException extends Exception {
public CustomerNotFoundException(){
	super();
}
	public String toString(){
		return "Customer not found";
	}

}
