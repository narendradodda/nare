package com.janapriyaRealEstateBuilders.daointerfaces;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.janapriyaRealEstateBuilders.beans.Customer;

public interface CustomerDao {

	 public abstract void addNewCustomer(Customer customer) throws ClassNotFoundException, SQLException;

	public abstract ResultSet getCustomerDetails(Customer customer) throws ClassNotFoundException, SQLException;

	public abstract void updateCustomerProfile(Customer customer) throws ClassNotFoundException, SQLException;

	public abstract void approveCustomer(Customer customer) throws ClassNotFoundException, SQLException;

	public abstract ResultSet getCustomerDetailsAdmin(Customer customer) throws ClassNotFoundException, SQLException;

	public abstract void mapCustomerToBuilding(Customer customer) throws ClassNotFoundException, SQLException;

	}

