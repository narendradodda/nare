package com.janapriyaRealEstateBuilders.daointerfaces;

import java.sql.SQLException;

import com.janapriyaRealEstateBuilders.beans.RequestBuilding;

public interface RequestBuildingDao{

	public abstract void requestABuilding(RequestBuilding requestBuilding) throws ClassNotFoundException, SQLException;

}
