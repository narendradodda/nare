package com.janapriyaRealEstateBuilders.daointerfaces;

import java.sql.SQLException;

import com.janapriyaRealEstateBuilders.beans.Customer;

public interface LoginDao {

	public abstract String validateUser(Customer loginInfo ) throws ClassNotFoundException, SQLException;
	
}
