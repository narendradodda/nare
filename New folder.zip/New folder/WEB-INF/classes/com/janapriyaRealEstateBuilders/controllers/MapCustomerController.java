package com.janapriyaRealEstateBuilders.controllers;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.janapriyaRealEstateBuilders.beans.Customer;
import com.janapriyaRealEstateBuilders.services.CustomerService;

/**
 * Servlet implementation class MapCustomerController
 */
public class MapCustomerController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MapCustomerController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("in map controller");
		String userName=request.getParameter("userName");
		String buildingId=request.getParameter("buildingId");
		
		Customer customer=new Customer();
		
		customer.setUserName(userName);
		customer.setBuildingId(buildingId);
		
		CustomerService customerService=new CustomerService();
		
		try {
			customerService.mapCustomerToBuilding(customer);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 request.setAttribute("message", "successfully mapped");
			getServletContext().getRequestDispatcher("/MapBuilding.jsp").include(request, response);
	}

}
