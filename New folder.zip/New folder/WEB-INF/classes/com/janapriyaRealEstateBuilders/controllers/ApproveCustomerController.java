package com.janapriyaRealEstateBuilders.controllers;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.janapriyaRealEstateBuilders.beans.Customer;
import com.janapriyaRealEstateBuilders.services.CustomerService;

/**
 * Servlet implementation class ApproveCustomerController
 */
public class ApproveCustomerController extends HttpServlet {
	private static final long serialVersionUID = 1L;

       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ApproveCustomerController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("inside controller");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("In Approve customer controller");
		String userName=request.getParameter("userName");
		
		Customer customer=new Customer();
		
		customer.setUserName(userName);
		
		CustomerService customerService=new CustomerService();
		try{
		customerService.approveCustomer(customer);
		}
		catch(ClassNotFoundException ce ){
	           
			ce.printStackTrace();
			           // append message to log file
			       }
			      
			 catch(SQLException se){
			           se.printStackTrace( );
			           // append message to log file
			       }
			     
			       
		    request.setAttribute("message", "approved successfully");
			getServletContext().getRequestDispatcher("/ApproveCustomer.jsp").forward(request, response);
		
		
		
	}

}
