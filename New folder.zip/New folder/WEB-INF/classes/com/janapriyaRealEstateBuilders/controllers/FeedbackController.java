package com.janapriyaRealEstateBuilders.controllers;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.janapriyaRealEstateBuilders.beans.Feedback;
import com.janapriyaRealEstateBuilders.services.FeedbackService;

/**
 * Servlet implementation class FeedbackController
 */
public class FeedbackController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FeedbackController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String userName=request.getParameter("userName");
		String feedback=request.getParameter("feedback");
		
		Feedback feedBack=new Feedback();
		
		feedBack.setUserName(userName);
		feedBack.setFeedback(feedback);
		
		FeedbackService feedbackService=new FeedbackService();
		
		try{
			feedbackService.sendFeedback(feedBack);
		}
		catch(ClassNotFoundException ce ){
	           
			ce.printStackTrace();
			           // append message to log file
			       }
			      
			 catch(SQLException se){
			           se.printStackTrace( );
			           // append message to log file
			       }
			     
			       
		    request.setAttribute("message", "feedback sent successfully");
			getServletContext().getRequestDispatcher("/CustomerFeedback.jsp").include(request, response);
		
		
	}

}
