package com.janapriyaRealEstateBuilders.daoimplementations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.janapriyaRealEstateBuilders.beans.Customer;
import com.janapriyaRealEstateBuilders.daointerfaces.CustomerDao;
import com.janapriyaRealEstateBuilders.utilities.DatabaseConnectionUtility;

public class CustomerDaoImplementation implements CustomerDao {
	ResultSet rs=null;

	@Override
	public void addNewCustomer(Customer customer)
			throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection con = DatabaseConnectionUtility.getConnection();
	
		PreparedStatement psmt = con.prepareStatement("insert into res_customer values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		         
		psmt.setString(1, customer.getUserName());
		psmt.setString(2, customer.getPassword());
		psmt.setString(3, customer.getFirstName());
		psmt.setString(4, customer.getLastName());
		psmt.setString(5, customer.getDateOfBirth());
		psmt.setString(6, customer.getGender());
		psmt.setString(7, customer.getAddress());
		psmt.setString(8, customer.getCity());
		psmt.setString(9, customer.getState());
		psmt.setString(10, customer.getPin());
		psmt.setString(11, customer.getSecurityQuestion());
		psmt.setString(12, customer.getSecurityAnswer());
		psmt.setString(13, customer.getStatus());
		psmt.setString(14, customer.getPrivilege());
		psmt.setString(15, customer.getRole());
		psmt.setString(16, customer.getBuildingId());
	
		psmt.executeUpdate();
		DatabaseConnectionUtility.closeConnection(con);
		    

	}

	@Override
	public ResultSet getCustomerDetails(Customer customer) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection con = DatabaseConnectionUtility.getConnection();
		ResultSet rs=null;
		 PreparedStatement psmt = con.prepareStatement("select * from res_customer where password=?");
		         
		psmt.setString(1, customer.getPassword());
		
		rs=psmt.executeQuery();
		
		return rs;
	}

	@Override
	public void updateCustomerProfile(Customer customer) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection con = DatabaseConnectionUtility.getConnection();
		 PreparedStatement psmt = con.prepareStatement("Update res_customer set password=?,first_name=?,last_name=?,address=?,state=?,city=?,pin=?,securityquestion=?,securityanswer=? where username=?");
			         
			psmt.setString(1, customer.getPassword());
			         
			psmt.setString(2, customer.getFirstName());
			
			psmt.setString(3, customer.getLastName());
			psmt.setString(4, customer.getAddress());
			psmt.setString(5, customer.getState());
			psmt.setString(6, customer.getCity());
			psmt.setString(7, customer.getPin());
			psmt.setString(8, customer.getSecurityQuestion());
			psmt.setString(9, customer.getSecurityAnswer()); 
			psmt.setString(10, customer.getUserName());
			psmt.executeUpdate();
			         
			DatabaseConnectionUtility.closeConnection(con);
	}

	@Override
	public void approveCustomer(Customer customer) throws ClassNotFoundException, SQLException{
		// TODO Auto-generated method stub
		Connection con = DatabaseConnectionUtility.getConnection();
		 PreparedStatement psmt = con.prepareStatement("Update res_customer set status='approved' where userName=?");
        
			psmt.setString(1, customer.getUserName());
			
			psmt.executeUpdate();
			DatabaseConnectionUtility.closeConnection(con);
		
	}

	@Override
	public ResultSet getCustomerDetailsAdmin(Customer customer) throws ClassNotFoundException, SQLException{
		// TODO Auto-generated method stub
		Connection con = DatabaseConnectionUtility.getConnection();
		ResultSet rs=null;
		 PreparedStatement psmt = con.prepareStatement("select * from res_customer where username=?");
		         
		psmt.setString(1, customer.getUserName());
		
		rs=psmt.executeQuery();
		
		return rs;
	}

	@Override
	public void mapCustomerToBuilding(Customer customer) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection con = DatabaseConnectionUtility.getConnection();
		 PreparedStatement psmt = con.prepareStatement("Update res_customer set building_Id=? where userName=?");
       
		 psmt.setString(1, customer.getBuildingId());
		 psmt.setString(2, customer.getUserName());
		 
		 psmt.executeUpdate();
		 DatabaseConnectionUtility.closeConnection(con);
	}

}
