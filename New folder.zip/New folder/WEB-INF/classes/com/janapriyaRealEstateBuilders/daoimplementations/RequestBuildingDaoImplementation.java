package com.janapriyaRealEstateBuilders.daoimplementations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.janapriyaRealEstateBuilders.beans.RequestBuilding;
import com.janapriyaRealEstateBuilders.daointerfaces.RequestBuildingDao;
import com.janapriyaRealEstateBuilders.utilities.DatabaseConnectionUtility;

public class RequestBuildingDaoImplementation implements RequestBuildingDao {

	@Override
	public void requestABuilding(RequestBuilding requestBuilding) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection con = DatabaseConnectionUtility.getConnection();
	       
		 PreparedStatement psmt = con.prepareStatement("insert into res_buildingrequest values(?,?)");
		 
		 psmt.setString(1, requestBuilding.getUserName());
		 psmt.setString(2, requestBuilding.getBuildingId());
		 
		 psmt.executeUpdate();
		 DatabaseConnectionUtility.closeConnection(con);
		         
	}

}
