package com.janapriyaRealEstateBuilders.daoimplementations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.janapriyaRealEstateBuilders.beans.Building;
import com.janapriyaRealEstateBuilders.daointerfaces.BuildingDao;
import com.janapriyaRealEstateBuilders.utilities.DatabaseConnectionUtility;

public class BuildingDaoImplementation implements BuildingDao {

	@Override
	public void addNewBuilding(Building building) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection con = DatabaseConnectionUtility.getConnection();
	       
		 PreparedStatement psmt = con.prepareStatement("insert into res_buildings values(?,?,?,?,?,?)");
		 
		 psmt.setString(1, building.getBuildingId());
		 psmt.setString(2, building.getBuildingName());
		 psmt.setString(3, building.getUserName());
		 psmt.setString(4, building.getCost());
		 psmt.setString(5, building.getRooms());
		 psmt.setString(6, building.getAddress());
		 
		 psmt.executeUpdate();
		 DatabaseConnectionUtility.closeConnection(con);
		         
		
	}

}
