package com.janapriyaRealEstateBuilders.services;

import java.sql.SQLException;

import com.janapriyaRealEstateBuilders.beans.Customer;
import com.janapriyaRealEstateBuilders.daoimplementations.LoginDaoImplementation;
import com.janapriyaRealEstateBuilders.daointerfaces.LoginDao;

public class LoginService {

	public String validateUser(Customer loginInfo) throws ClassNotFoundException, SQLException{
		LoginDao loginDao = new LoginDaoImplementation();
		return loginDao.validateUser(loginInfo);
	}
}
